"""VeSync API Library."""

# pylint: skip-file
# flake8: noqa

import logging
from .vesync import VeSync

__version__ = '2.1.17'

logging.basicConfig(
    level=logging.INFO, format='%(asctime)s - %(levelname)5s - %(message)s'
)
